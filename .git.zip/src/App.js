import logo from './logo.svg';
import './App.css';
import { PowerBIEmbed } from 'powerbi-client-react';
import { models } from "powerbi-client"


function App() {
  return (
    <div className="App">
      <header className="App-header">
        <PowerBIEmbed
          embedConfig={{
            type: 'report',   // Supported types: report, dashboard, tile, visual, qna, paginated report and create
            id: 'c278183b-2ccd-47fb-a962-c9d5ebaeed8f',
            embedUrl: 'https://app.powerbi.com/reportEmbed?reportId=c278183b-2ccd-47fb-a962-c9d5ebaeed8f&config=eyJjbHVzdGVyVXJsIjoiaHR0cHM6Ly9XQUJJLVVTLUVBU1QyLUMtUFJJTUFSWS1yZWRpcmVjdC5hbmFseXNpcy53aW5kb3dzLm5ldCIsImVtYmVkRmVhdHVyZXMiOnsibW9kZXJuRW1iZWQiOnRydWUsInVzYWdlTWV0cmljc1ZOZXh0Ijp0cnVlfX0%3d',

            accessToken: "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyIsImtpZCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyJ9.eyJhdWQiOiJodHRwczovL2FuYWx5c2lzLndpbmRvd3MubmV0L3Bvd2VyYmkvYXBpIiwiaXNzIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvM2FjOTRiMzMtOTEzNS00ODIxLTk1MDItZWFmZGE2NTkyYTM1LyIsImlhdCI6MTY4NzMzODE2OSwibmJmIjoxNjg3MzM4MTY5LCJleHAiOjE2ODczNDM4MTIsImFjY3QiOjAsImFjciI6IjEiLCJhaW8iOiJBVlFBcS84VEFBQUFSTEFOL3lEOXdNc00vS21LQWFQa1I5WTRaN3BDRUFqc25UcW1XMkVzUWFsbXhFSlFidllFRGlEdmppL1puWXVhUko3R0ZtZ0F5RC9QbTdrQlpQWTcxeDVPZkdxQW9Iak9DVE9UZU5WYVdNOD0iLCJhbXIiOlsibWZhIl0sImFwcGlkIjoiODcxYzAxMGYtNWU2MS00ZmIxLTgzYWMtOTg2MTBhN2U5MTEwIiwiYXBwaWRhY3IiOiIwIiwiZmFtaWx5X25hbWUiOiJib3JyYSIsImdpdmVuX25hbWUiOiJzaGl2YSIsImlwYWRkciI6IjI0MDE6NDkwMDoyNzkyOjhjM2Q6ZTQ5NDo5ZWYyOjU2ZTA6NjEyNiIsIm5hbWUiOiJCb3JyYSwgU2hpdmEgW0dUU1VTIE5PTi1KXHUwMDI2Sl0iLCJvaWQiOiI5ZTkwNjAwYi0yZDA4LTQ2YTUtYjFiMC00N2Q5OWJhNTRlNGQiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtMTYxNDg5NTc1NC0yMTQ2ODQ3OTgxLTE2MDY5ODA4NDgtMTY3MjM4MyIsInB1aWQiOiIxMDAzMjAwMjM0REVBQzExIiwicmgiOiIwLkFRUUFNMHZKT2pXUklVaVZBdXI5cGxrcU5Ra0FBQUFBQUFBQXdBQUFBQUFBQUFBRUFBQS4iLCJzY3AiOiJ1c2VyX2ltcGVyc29uYXRpb24iLCJzaWduaW5fc3RhdGUiOlsia21zaSJdLCJzdWIiOiJRUnNFdWNzU0RTLWlPRnVlY1htWjJfNllCdEdUMi1RWG04TXluTHdHSE44IiwidGlkIjoiM2FjOTRiMzMtOTEzNS00ODIxLTk1MDItZWFmZGE2NTkyYTM1IiwidW5pcXVlX25hbWUiOiJTQm9ycmEyQGl0cy5qbmouY29tIiwidXBuIjoiU0JvcnJhMkBpdHMuam5qLmNvbSIsInV0aSI6IkdjZnpBZUFRbDBtTWpkOWNhTXc0QUEiLCJ2ZXIiOiIxLjAiLCJ3aWRzIjpbImI3OWZiZjRkLTNlZjktNDY4OS04MTQzLTc2YjE5NGU4NTUwOSJdfQ.orPMSanlyG0ASWQOML8mZbX6ABtyyLlXBNLILD8EUh239ASrOT17A8971QthTxgSlzro-BzObiH2ansQ87PMMg0KneVfeiATx1W_Q_FfAB91nnWJ1u-I8WTp-Bbo-uqNlqBOKR6nV5Myecn0ZCgCUx0VCyDTbZScDXvsMhZyKILhUniB4sIlfhR2WUnmU8pMhq2gtlh_Pzysg1fws-nF_aQkn3C2yZDM4ftKsVbKxwYGNIR-dvk1TUAMmIOc5HNXEdABMe9pFkOl1FJqs5Y9HdynWtDYRb0PCHn77e7u_p3LIlPRBEBipRn3X7tBMPAnvceJENWQzS1aQyEt6O2ytg",
            tokenType: models.TokenType.Embed, // Use models.TokenType.Aad for SaaS embed
            settings: {
              panes: {
                filters: {
                  expanded: false,
                  visible: false
                }
              },
              background: models.BackgroundType.Transparent,
            }
          }}

          eventHandlers={
            new Map([
              ['loaded', function () { console.log('Report loaded'); }],
              ['rendered', function () { console.log('Report rendered'); }],
              ['error', function (event) { console.log(event.detail); }],
              ['visualClicked', () => console.log('visual clicked')],
              ['pageChanged', (event) => console.log(event)],
            ])
          }

          cssClassName={"reportClass"}

          getEmbeddedComponent={(embeddedReport) => {
            window.report = embeddedReport
          }}
        />
      </header>
    </div>
  );
}

export default App;
