// import logo from './logo.svg';
import './App.css';
import { PowerBIEmbed } from 'powerbi-client-react';
import { models } from "powerbi-client"


function App() {
  return (
    <div className="App">

      <PowerBIEmbed
        embedConfig={{
          type: 'report',   // Supported types: report, dashboard, tile, visual, qna, paginated report and create
          id: "1c7c5913-f2fd-4fb3-b89f-8a65e1dc1d6a",
          embedUrl: "https://app.powerbi.com/reportEmbed?reportId=1c7c5913-f2fd-4fb3-b89f-8a65e1dc1d6a&groupId=4b39d1e5-8d21-45df-be7b-9e702135acc6&w=2&config=eyJjbHVzdGVyVXJsIjoiaHR0cHM6Ly9XQUJJLVVTLUNFTlRSQUwtQi1QUklNQVJZLXJlZGlyZWN0LmFuYWx5c2lzLndpbmRvd3MubmV0IiwiZW1iZWRGZWF0dXJlcyI6eyJtb2Rlcm5FbWJlZCI6dHJ1ZSwidXNhZ2VNZXRyaWNzVk5leHQiOnRydWV9fQ%3d%3d",

          accessToken: "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyIsImtpZCI6Ii1LSTNROW5OUjdiUm9meG1lWm9YcWJIWkdldyJ9.eyJhdWQiOiJodHRwczovL2FuYWx5c2lzLndpbmRvd3MubmV0L3Bvd2VyYmkvYXBpIiwiaXNzIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvM2ZmN2QzNWUtNzI2MS00NWIyLWEzMTQtZGYwODRlOWEyMWI3LyIsImlhdCI6MTY4NzM1MjUwMywibmJmIjoxNjg3MzUyNTAzLCJleHAiOjE2ODczNTc5NDksImFjY3QiOjAsImFjciI6IjEiLCJhaW8iOiJBVFFBeS84VEFBQUFFMHJKMDlDN2xQQm9ndnFDL0IyQnVGMjE5cnoycU4xYW9FYjdQclVZVHdlL2x3VE0rVy9ueDl3MG1SbllQVTU4IiwiYW1yIjpbInB3ZCJdLCJhcHBpZCI6Ijg3MWMwMTBmLTVlNjEtNGZiMS04M2FjLTk4NjEwYTdlOTExMCIsImFwcGlkYWNyIjoiMCIsImZhbWlseV9uYW1lIjoiTWFtaWxsYSIsImdpdmVuX25hbWUiOiJTaGl2YSBTaGFua2FyIiwiaXBhZGRyIjoiMTgzLjgyLjEyNS40MyIsIm5hbWUiOiJTaGl2YSBTaGFua2FyIE1hbWlsbGEiLCJvaWQiOiIyMzE3ODEzMS02NTQ2LTQ1ZTktOTI0ZC0zMjRmNmY2MGZlMWEiLCJwdWlkIjoiMTAwMzIwMDI5MDZGOTI4MyIsInB3ZF9leHAiOiIzMTE2OTIzNjYiLCJwd2RfdXJsIjoiaHR0cHM6Ly9wcm9kdWN0aXZpdHkuc2VjdXJlc2VydmVyLm5ldC9taWNyb3NvZnQ_bWFya2V0aWQ9ZW4tVVNcdTAwMjZlbWFpbD1zaGl2YS5tYW1pbGxhJTQwYWlmYWxhYnMuY29tXHUwMDI2c291cmNlPVZpZXdVc2Vyc1x1MDAyNmFjdGlvbj1SZXNldFBhc3N3b3JkIiwicmgiOiIwLkFYMEFYdFAzUDJGeXNrV2pGTjhJVHBvaHR3a0FBQUFBQUFBQXdBQUFBQUFBQUFDYUFHWS4iLCJzY3AiOiJ1c2VyX2ltcGVyc29uYXRpb24iLCJzaWduaW5fc3RhdGUiOlsia21zaSJdLCJzdWIiOiJHU3Rtdm9VbTgwLUwwTlR6RnRGbUJBdHpzZE1XWHhvNFh5U2hPY0xaN09BIiwidGlkIjoiM2ZmN2QzNWUtNzI2MS00NWIyLWEzMTQtZGYwODRlOWEyMWI3IiwidW5pcXVlX25hbWUiOiJzaGl2YS5tYW1pbGxhQGFpZmFsYWJzLmNvbSIsInVwbiI6InNoaXZhLm1hbWlsbGFAYWlmYWxhYnMuY29tIiwidXRpIjoiTFZBX0JfTWxIVXU4ZG5RdlBob2pBQSIsInZlciI6IjEuMCIsIndpZHMiOlsiYjc5ZmJmNGQtM2VmOS00Njg5LTgxNDMtNzZiMTk0ZTg1NTA5Il19.lHgV361vYlpPVB5dzoBk_ptiHA4KFuQNLElWKTzR6biYvCrdnNHssLLXu112HnFCl7RcHN7_R2pdYs3GXgBhHgQULiHmQ7AgIrDwDysXg9uUhurxYBYrSdRXnHT3JRm5r-7rFhink-OiB0sQkepry4YFsf2ZjdF4sv3PpV812a5IVHS6pa8gcPBpWFJeg3ReTQIhiQUjt-AdbIAzAEA3uFr8WWmYixBw6RMTf3e8qKaNv9mfn0oTpz7YvSHoQYSAWo_I6RkmctZQFLW2uCKUMbvRirNtZVpF5_TSPjd0nf2fpAH5TENGBjPCzYA7hZ_KZjJwwkdfPTnSpuRzOR1KOg",
          // accessToken: "access-token",
          tokenType: models.TokenType.Aad, // Use models.TokenType.Aad for SaaS embed
          settings: {
            panes: {
              filters: {
                expanded: false,
                visible: false
              }
            },
            // background: models.BackgroundType.Transparent,
          }
        }}

        eventHandlers={
          new Map([
            ['loaded', function () { console.log('Report loaded'); }],
            ['rendered', function () { console.log('Report rendered'); }],
            ['error', function (event) { console.log(event.detail); }],
            ['visualClicked', () => console.log('visual clicked')],
            ['pageChanged', (event) => console.log(event)],
          ])
        }

        cssClassName={"embed-conatiner"}

        getEmbeddedComponent={(embeddedReport) => {
          window.report = embeddedReport
        }}



      />
      <div style={{ display: "flex", flexDirection: "row", justifyContent: "flex-end" }}>
        <img src="https://img.freepik.com/premium-vector/robot-icon-chat-bot-sign-support-service-concept-chatbot-character-flat-style_41737-796.jpg" style={{ height: "150px" }} alt="icon" />
      </div>

    </div>
  );
}

export default App;
